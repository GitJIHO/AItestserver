#include <stdio.h>
#include <curses.h>
#include <unistd.h>

int main() {
	initscr();

	clear();
	while(1){
		move(10,20);
		addstr("Hello, world");
		refresh();
		sleep(1);
		clear();
		refresh();
		sleep(1);
	}

	getch();
	endwin();

	return 0;
}
